{
"站名": "4K",
"主页url": "https://www.4kvm.com",
"请求头": "",
"头部集合": "User-Agent$Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1",
"热门推荐": "1",
"起始页": "1",
"直接播放": "0",
"倒序播放": "0",
"图片代理": "0",
"二次截取": "",
"数组": "<div class=\"poster\">&&<div class=\"texto\">",
"图片": "src=\"&&\"",
"标题": "alt=\"&&\"",
"副标题": "class=\"icon-star2\">&&<div class=\"mepo\">",
"链接": "href=\"&&\"",
"链接前缀": "",

"线路二次截取": "",
"线路数组": "<div class=\'se-q\'>&&</a>",
"线路标题": "class=\'title\'>&&</span>",
"线路链接": "href=\"&&\"",

"状态": "<div class=\"extra\">&&</div>",
"导演": "<div id=\"cast\" class=\"sbox fixidtab\">&&<h2>演员</h2>",
"主演": "<h2>演员</h2>&&<div id=\"info",
"简介": "<p>&&</p>",

"播放二次截取": "id=\'playernotice&&<div class=\"sheader\">[替换:class=\'ajax_mode\'>>>videourls:你我\"name\":1集,\"链洁\":\\&mvsource=0\"和他tables:]",
"播放数组": "videourls:&&tables:[替换:url\":>>链洁\":\\&ep=#name\":>>name\":第#}>>\\&source=0\"和他#{>>你我]",
"列表二次截取": "",
"播放列表": "你我&&和他",
"播放标题": "name\":&&,",
"播放链接": "链洁\":&&\"",
"播放链接前缀": "name=\"postid\" v&&\">[替换:alue=\">>https://www.4kvm.com/dplayer?id=]",
"播放链接后缀": "",
"免嗅": "0",
"嗅探词":".css",
"过滤词":"",
"播放请求头": "User-Agent$Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1",

"搜索url": "https://www.4kvm.com/wp-json/dooplay/search/?keyword={wd}&nonce=c1c25fbc3d",
"搜索模式": "1",
"搜索二次截取": "",
"搜索数组": "{\"t&&}",
"搜索图片": "img\":\"&&\"",
"搜索标题": "itle\":\"&&\"",
"搜索链接": "url\":\"&&\"",
"搜索链接前缀": "",

"分类url": "https://www.4kvm.com/{cateId}/page/{catePg}",
"分类": "电影$movies#国产剧$classify/guochan#美剧$classify/meiju#韩剧$classify/hanju#番剧$classify/fanju#评分榜$ratings",
//#热门播放$trending
"分类二次截取": "",
"分类数组": "",
"分类标题": "",
"分类ID": "",
"类型": "",
"剧情": "",

"地区": "",

"年份": "",

"排序": "",

"筛选": ""
}